package ch.epfl.javions;

import java.util.Objects;


public class Bits {
    private Bits(){}
    public static int extractUInt(long value, int start, int size){
        Preconditions.checkArgument(size > 0 && size < Integer.SIZE );
        Objects.checkFromIndexSize(start, size, Long.SIZE);

        value <<= Long.SIZE - (size + start);
        value >>>= Long.SIZE - size ;
        return (int) value;
    }

    public static boolean testBit(long value, int index){
        Objects.checkIndex( index, Long.SIZE);

        value >>>= index;

        return (value  & 1) == 1;
    }
}
