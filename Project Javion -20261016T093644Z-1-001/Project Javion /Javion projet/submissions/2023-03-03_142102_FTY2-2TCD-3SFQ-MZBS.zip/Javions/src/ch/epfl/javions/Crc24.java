package ch.epfl.javions;

/**
 * Représente un calculateur de CRC de 24 bits
 */
public final class Crc24 {

    /**
     *  Les 24 bits de poids faible du générateur utilisé pour calculer le CRC24 des messages ADS-B,
     */
    public final static int GENERATOR = 0xFFF409;

    /**
     *
     */
    private int generator;

    /**
     * Constructeur public
     *
     * @param generator
     */
    public Crc24(int generator) {
    }

    /**
     * Retourne le CRC24 du tableau donné
     *
     * @param bytes tableau d'octets donné
     * @return
     */
    public int crc(byte[] bytes) {
        return crc_bitwise(GENERATOR, bytes);
    }


    /**
     * Retourne le CRC24 du tableau donné en utilisant le generateur passé en argument
     *
     * @param generator générateur
     * @param bytes tableau d'octets
     * @return le CRC24
     */
    private static int crc_bitwise(int generator, byte[] bytes) {
        long crc24 = 0;
        for (int i = 0; i < bytes.length; i++) {
            for (int j = 7; j >= 0; j--) {
                crc24 = (crc24 << 1) | Bits.extractUInt(bytes[i], j, 1);
                if (Bits.extractUInt(crc24, 24, 1) == 1) {
                    crc24 = crc24 ^ generator;
                }
            }
        }
        for ( int i =0; i < 24; i++){
            crc24 = (crc24 << 1);
            if (Bits.extractUInt(crc24, 24, 1) == 1) {
                crc24 = crc24 ^ generator;
            }
        }
        return Bits.extractUInt(crc24, 0, 24);
    }


    private static int crc_bitwise_2(int generator, byte[] bytes) {
        long crc24 = 0;
        return Bits.extractUInt(crc24, 0, 24);
    }

    /**
     *     crc = 0
     * pour chaque bit b du message augmenté, de gauche à droite:
     *   si crc[N - 1] == 1:
     *     crc = ((crc << 1) | b) ^ G′
     *   sinon:
     *     crc = (crc << 1) | b
     * crc = N bits de poids faible de crc
     */
}



